﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Latihan6
{
    public class looping
    {
        public void forloop(int ayam)
        {
            for (int i = ayam; i > 0; i--)
			{
                if((i)==1)
                {
                    Console.WriteLine("Anak ayam turun " + i.ToString() + ", mati 1 jadi mati semua");
                }
                else
                {
                    Console.WriteLine("Anak ayam turun " + i.ToString() + ", mati 1 jadi tinggal " + (i - 1).ToString());
                }
			}
        }
        public void forloop2(int p, int l)
        {
            
            for (int i = 0; i <= l; i++)
            {
               for(int z=0;z<=p;z++)
               {
                   if(i==0 || i==l)
                   {
                       Console.Write("*");  
                   }
                   else
                   {
                       if(z==0 || z==p)
                       {
                            Console.Write("*");  
                        }
                       else
                       {
                            Console.Write(" ");  
                       }
                   }
               }

               Console.WriteLine(" ");  
            }
        }
        public void forloop3(int p, int l)
        {
            int l2 = l / 2;
            int p2 = p / 2;
            int p3 = 1;
            for (int i = 0; i <= l; i++)
            {
                if (i < l2)
                {
                    for (int z = 0; z <= p; z++)
                    {
                        if (i == 0 || i == l)
                        {
                            if (z == p2)
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                        else
                        {
                            if (z >= (l2 - p3) && z <= (l2 + p3))
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                    }
                    p3 = p3 + 1;
                }
                else
                {
                    p3 = p3 - 1;
                    for (int z = 0; z <= p; z++)
                    {
                        if (i == 0 || i == l)
                        {
                            if (z == p2)
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                        else
                        {
                            if (z >= (l2 - p3) && z <= (l2 + p3))
                            {
                                Console.Write("*");
                            }
                            else
                            {
                                Console.Write(" ");
                            }
                        }
                    }

                }
                Console.WriteLine(" ");
            }
        }
    }
}
