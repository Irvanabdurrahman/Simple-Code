﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Latihan2
{
    public class PersegiPanjang
    {
        public void Luas()
        {
            Console.WriteLine("Masukan Panjang!");
            double P = 0;
            string P2 = Console.ReadLine();
            double.TryParse(P2, out P);

            Console.WriteLine("Masukan Lebar!");
            double L = 0;
            string L2 = Console.ReadLine();
            double.TryParse(L2, out L);

            double luas = P * L;
            Console.WriteLine("Luas =" + luas);
            Console.ReadKey();
        }
    }
}
