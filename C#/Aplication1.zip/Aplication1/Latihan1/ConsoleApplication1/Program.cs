﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static List<Mahasiswa> ListOfmhs = new List<Mahasiswa>();
        static List<Nilai> ListOfnilai = new List<Nilai>();
        static void Main(string[] args)
        {
            string ulang="y";
            while (ulang.ToLower() == "y")
            {
                Console.WriteLine("\n\n=============================");
                Console.WriteLine("        MENU UTAMA           ");
                Console.WriteLine("=============================");
                Console.WriteLine("1. Input Mahasiswa");
                Console.WriteLine("2. Input Nilai");
                Console.WriteLine("3. Cetak Mahasiswa");
                Console.WriteLine("4. Cetak Nilai");
                Console.WriteLine("5. Cari Mahasiswa Berdasarkan NIM");
                Console.WriteLine("6. List Mahasiswa Berdasarkan Kota");
                Console.WriteLine("7. Keluar");
                Console.WriteLine("\nPilihan Anda?");
                string menu2 = Console.ReadLine();
                switch(menu2)
                {

                    case "1":
                        {
                            InputMahasiswa();
                            break;
                        }

                    case "2":
                        {
                            InputNilai();
                            break;
                        }

                    case "3":
                        {
                            CetakMahasiswa();
                            break;
                        }
                    case "4":
                        {
                            CetakNilai();
                            break;
                        }
                    case "5":
                        {
                            CariMahasiswa("1");
                            break;
                        }
                    case "6":
                        {
                            CariMahasiswa("2");
                            break;
                        }
                    case "7":
                        {
                            ulang = "n";
                            break;
                        }
                    default :
                        {
                            Console.WriteLine("MENU TIDAK TERDAFTAR");
                            break;
                        }
                }

                if(ulang!="n")
                {
                    Console.WriteLine("Ulang lagi? (y/Y)");
                    ulang = Console.ReadLine();
                }
            }


            //Console.ReadKey();
        }
        
        static void InputMahasiswa()
        {
            Console.WriteLine("Masukan jumlah data : ");
            int jumlahdata = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < jumlahdata; i++)
            {
                Mahasiswa mhs = new Mahasiswa();
                Console.WriteLine("\nNIK            : ");
                string NIK = Console.ReadLine();

                mhs.MahasiswaID = NIK;
                Console.WriteLine("Nama Mahasiswa : ");
                mhs.NamaMahasiswa = Console.ReadLine();
                Console.WriteLine("Kota Mahasiswa :");
                mhs.kota = Console.ReadLine();
                ListOfmhs.Add(mhs);
            }

          }


        static void CetakMahasiswa()
        {

            Console.WriteLine("\n-----------------------------------------");
            Console.WriteLine("NIM\tNAMA\t\tKOTA");
            Console.WriteLine("-----------------------------------------");
            foreach (var mhs in ListOfmhs)
            {
                Console.WriteLine("" + mhs.MahasiswaID + "\t" + mhs.NamaMahasiswa + "\t\t" + mhs.kota);
                Console.WriteLine("-----------------------------------------");
            }
        }

        static void InputNilai()
        {
            Console.WriteLine("Masukan jumlah data : "); 
            int jumlahdata = Convert.ToInt32(Console.ReadLine());
            for (int i = 0; i < jumlahdata; i++)
            {
                Nilai nla = new Nilai();
                Console.WriteLine("\nNIK            : ");
                string NIK = Console.ReadLine();

                nla.MahasiswaID = NIK;
                Console.WriteLine("UAS            :");
                nla.uas = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("UTS            :");
                nla.uts = Convert.ToInt32(Console.ReadLine());
                ListOfnilai.Add(nla);
            }

        }

        static void CetakNilai()
        {
            int uas = 0;
            int uts = 0;
            int total = 0;
            string huruf = string.Empty;

            Console.WriteLine("\n\n----------------------------------------------");
            Console.WriteLine("NIM\tUAS\tUTS\tTOTAL NILAI\tHURUF");
            Console.WriteLine("----------------------------------------------");
            int index = 0;

            foreach (var nla in ListOfnilai)
            {
                uas = nla.uas;
                uts = nla.uts;
                huruf = nla.nilaihuruf();
                total = nla.ratarata();
                Console.WriteLine(nla.MahasiswaID + "\t" + uas + "\t" + uts + "\t" + total + "\t\t" + huruf);
                Console.WriteLine("----------------------------------------------");
            }
        }

        static void CetakNilaiTot()
        {

            int uas = 0;
            int uts = 0;
            int total = 0;
            string huruf = string.Empty;
            Console.WriteLine("\n\n----------------------------------------------------------");
            Console.WriteLine("NILAI\tNAMA\t KOTA\tUAS\tUTS\tTOTAL NILAI\tHURUF");
            Console.WriteLine("----------------------------------------------------------");


            foreach (var mhs in ListOfmhs)
            {
                uas = 0;
                uts = 0;
                total = 0;
                huruf = string.Empty;
                foreach (var nla in ListOfnilai)
                {
                    if (mhs.MahasiswaID == nla.MahasiswaID)
                    {
                        uas = nla.uas;
                        uts = nla.uts;
                        huruf = nla.nilaihuruf();
                        total = nla.ratarata();
                        break;
                    }
                }

                if (total > 0)
                {
                    Console.WriteLine(mhs.MahasiswaID + "\t" + mhs.NamaMahasiswa + "\t" + mhs.kota + "\t" + uas + "\t" + uts + "\t" + total + "\t\t" + huruf);

                    Console.WriteLine("-----------------------------------------------------------");
                }
            }
        }


        static void CariMahasiswa(string type)
        {
            if(type=="1")
            {

                Console.WriteLine("Masukan NIM : ");
                string data = Console.ReadLine();
                Console.WriteLine("\n-----------------------------------------");
                Console.WriteLine("NIM\tNAMA\t\tKOTA");
                Console.WriteLine("-----------------------------------------");
                foreach (var mhs in ListOfmhs)
                {
                    if(mhs.MahasiswaID==data)
                    {
                        Console.WriteLine("" + mhs.MahasiswaID + "\t" + mhs.NamaMahasiswa + "\t\t" + mhs.kota);
                        Console.WriteLine("-----------------------------------------");
                    }
                }
            }
            else if(type=="2")
            {

                Console.WriteLine("Masukan Kota : ");
                string data = Console.ReadLine();
                Console.WriteLine("\n-----------------------------------------");
                Console.WriteLine("NIM\tNAMA\t\tKOTA");
                Console.WriteLine("-----------------------------------------");
                foreach (var mhs in ListOfmhs)
                {
                    if (mhs.kota.ToLower() == data.ToLower())
                    {
                        Console.WriteLine("" + mhs.MahasiswaID + "\t" + mhs.NamaMahasiswa + "\t\t" + mhs.kota);
                        Console.WriteLine("-----------------------------------------");
                    }
                }

            }
        }
        public struct Mahasiswa
        {
            public string MahasiswaID;
            public string NamaMahasiswa;
            public string kota;
            
        }


        public struct Nilai
        {
            public string MahasiswaID;
            public int uas;
            public int uts;

            public string nilaihuruf()
            {
                int P = ((uas + uts) / 2);
                string nilai;
                if (P < 50)
                {
                    nilai = "D";
                }
                else if (P >= 50 && P < 70)
                {
                    nilai = "C";
                }
                else if (P >= 70 && P < 80)
                {
                    nilai = "B";
                }
                else
                {
                    nilai = "A";
                }
                return nilai;
            }
            public int ratarata()
            {
                int P = ((uas + uts) / 2);
               
                return P;
            }
        }
    }
}
