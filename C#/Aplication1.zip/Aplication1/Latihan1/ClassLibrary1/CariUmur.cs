﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace umurdll
{
    public class umur
    {
        public void hitungumur()
        {

            int day1;
            int month;
            int year;

            Console.Out.WriteLine("Menghitung Umur    ");
            Console.Out.WriteLine("====================");
            try
            {
                Console.Out.Write("Masukan Tanggal : ");
                day1 = Convert.ToInt32(Console.In.ReadLine());
                if (day1 > 31 || day1 <= 0)
                {
                    Console.WriteLine("Hari salah!");
                }
                else
                {
                    Console.Out.Write("Masukan Bulan :");
                    month = Convert.ToInt32(Console.In.ReadLine());
                    if (month > 12 || month <= 0)
                    {
                        Console.WriteLine("Bulan salah!");
                    }
                    else
                    {
                        Console.Out.Write("Masukan Tahun :");
                        year = Convert.ToInt32(Console.In.ReadLine());
                        if (year > 2000)
                        {
                            Console.WriteLine("Tahun lebih dari 2000");

                        }
                        else
                        {
                            DateTime birthDate = new DateTime(year, month, day1);
                            DateTime today = DateTime.Now;
                            Cetakumur(birthDate, today);
                        }
                    }
                }
            }
            catch (FormatException e)
            {
                Console.Out.WriteLine("Data tidak berupa angka");

            }
            catch (Exception e)
            {
                Console.WriteLine("Terjadi Kesalahan :" + e.Message);

            }
            Console.ReadKey();
        }

        private static void Cetakumur(DateTime birthDate, DateTime today)
        {
            TimeSpan age = today.Subtract(birthDate);
            Console.Out.WriteLine("Saat ini umur anda " + (age.Days / 365) + " tahun, " + age.Days + " hari, " + age.Hours + " Jam, " + age.Minutes + " Menit!");

        }
    }
}
