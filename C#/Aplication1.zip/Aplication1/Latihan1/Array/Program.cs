﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            String[] ArrayOfInt = new String[5];

            for (int i = 0; i < ArrayOfInt.Length; i++)
            {
                Console.WriteLine("Isi value array ke-" + i);
                ArrayOfInt[i] = Console.ReadLine();
            }
            for (int i = 0; i < ArrayOfInt.Length; i++)
            {
                Console.WriteLine("Value Array ke " + i + " = " + ArrayOfInt[i]);
            }
            Console.ReadKey();
        }
    }
}
