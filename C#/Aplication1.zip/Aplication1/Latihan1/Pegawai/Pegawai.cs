﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pegawai
{
    class DataPegawai
    {
        static void Main(string[] args)
        {
            List<PegawaiData> ListOfmhs = new List<PegawaiData>();
            Console.WriteLine("Masukan jumlah data : ");
            int jumlahdata = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < jumlahdata; i++)
            {
                PegawaiData mhs = new PegawaiData();
                Console.WriteLine("\nNIP            : ");
                string NIK = Console.ReadLine();

                mhs.NIP = NIK;
                Console.WriteLine("Nama Pegawai : ");
                mhs.Nama = Console.ReadLine();
                Console.WriteLine("Mulai Bekerja(dd-MM-yyyy) :");
                mhs.MulaiKerja = Console.ReadLine();
                ListOfmhs.Add(mhs);
            }


            Console.WriteLine("\n\n--------------------------------------------------------");
            Console.WriteLine("NIM\tNAMA\t\tMulai Kerja\t\tMasa Kerja Tahun/Bulan");
            Console.WriteLine("--------------------------------------------------------");
            foreach (var mhs in ListOfmhs)
            {
                string[] tanggalmasuk = mhs.MulaiKerja.Split('-');
                int tahun = Convert.ToInt32(tanggalmasuk[2]);
                int bulan = Convert.ToInt32(tanggalmasuk[1]);
                int hari = Convert.ToInt32(tanggalmasuk[0]);
                DateTime tanggalmasuk2 = new DateTime(tahun, bulan, hari);
                DateTime today = DateTime.Now;
                TimeSpan age = today.Subtract(tanggalmasuk2);
                decimal masatahun = Convert.ToDecimal(age.Days) / 365;
                decimal sisabulan = masatahun - Math.Floor(masatahun);
                decimal masabulan = Math.Floor(sisabulan * 12);
                //int masabulan = (age.Days / 30) - (masatahun * 12);
                Console.WriteLine("" + mhs.NIP + "\t" + mhs.Nama + "\t\t" + mhs.MulaiKerja + "\t\t" + Math.Floor(masatahun) + "/" + masabulan);
                Console.WriteLine("--------------------------------------------------------");
            }
            Console.ReadKey();
        }
        public struct PegawaiData
        {
            public string NIP;
            public string Nama;
            public string MulaiKerja;

        }
    }
}
