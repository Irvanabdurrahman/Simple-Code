﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Menu
{
    public class MenuUtama
    {
        public string menu()
        {
            Console.WriteLine("=============================");
            Console.WriteLine("        MENU UTAMA           ");
            Console.WriteLine("=============================");
            Console.WriteLine("1. Cari Umur");
            Console.WriteLine("2. Nilai Ujian");
            Console.WriteLine("3. Parameter");
            Console.WriteLine("4. Looping");
            Console.WriteLine("5. Hitung Luas");
            Console.WriteLine("\nPilihan Anda?"); 
            string menu2 = Console.ReadLine();
            return menu2;
        }
    }
}
