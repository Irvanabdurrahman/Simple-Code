﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ValidasiNilai
{
    public class NilaiUjian
    {
        public void Validasi()
        {

            Console.WriteLine("\nMasukan Jumlah Nilai Yang Di Input : ");
            string Arr = Console.ReadLine();
            int[] Arraynilai = new int[Convert.ToInt32(Arr)];

            for (int i = 0; i < Arraynilai.Length; i++)
            {
                Console.WriteLine("Isi nilai ke-" + i);
                Arraynilai[i] = Convert.ToInt32(Console.ReadLine());
            }
            string nilai="";
            for (int i = 0; i < Arraynilai.Length; i++)
            {
                int P = Arraynilai[i];
                if (P < 50)
                {
                    nilai = "D";
                }
                else if (P >= 50 && P < 70)
                {
                    nilai = "C";
                }
                else if (P >= 70 && P < 80)
                {
                    nilai = "B";
                }
                else
                {
                    nilai = "A";
                }
                Console.WriteLine("Nilai ke " + P + " = " + nilai);
            }


            
        }
    }
}
