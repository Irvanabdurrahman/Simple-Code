﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parameter
{
    public class Foo
    {
        private static void FooMethod(int x, out int y, ref int z)
        {
            x = x * 10;
            y = x + 10;
            z = x * 100;

        }
        public void cetakFoo()
        {
            int a = 10;
            int b;
            int c = 0;
            FooMethod(a, out b, ref c);
            Console.WriteLine("Nilai A = " + a);
            Console.WriteLine("Nilai B = " + b);
            Console.WriteLine("Nilai C = " + c);

            Console.ReadKey();

        }
    }
}
