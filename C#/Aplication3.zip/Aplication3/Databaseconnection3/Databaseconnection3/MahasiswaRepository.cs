﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Databaseconnection3
{
    class MahasiswaRepository
    {
        public List<Mahasiswa> GetMahasiswaByKota(List<String> Kota)
        {
            List<Mahasiswa> result = new List<Mahasiswa>();
            using(var db=new trainingEntities())
            {
                result = (from m in db.Mahasiswas
                          where Kota.Contains(m.Kota)
                          select m).ToList();
            }
            return result;
        }

        public void AddData(Mahasiswa data)
        {
            using(var db = new trainingEntities())
            {
                db.Mahasiswas.Add(data);
                db.SaveChanges();
            }
        }


        public void EditData(int ID,string nama,string kota)
        {
            using (var db = new trainingEntities())
            {
                Mahasiswa result = (from m in db.Mahasiswas
                          where m.ID == ID
                          select m).FirstOrDefault();
                result.Nama = nama;
                result.Kota = kota;
                db.SaveChanges();
            }

        }
        public void DeleteData(int ID)
        {
            using (var db = new trainingEntities())
            {
                Mahasiswa result = (from m in db.Mahasiswas
                                    where m.ID == ID
                                    select m).FirstOrDefault();
                db.Mahasiswas.Remove(result);
                db.SaveChanges();
            }

        }
        

        public List<GetListNamaMahasiswaByKota_Result> GetMahasiswaByKotaProc(string Kota)
        {
            List<GetListNamaMahasiswaByKota_Result> result = new List<GetListNamaMahasiswaByKota_Result>();
            using (var db = new trainingEntities())
            {
                result = db.GetListNamaMahasiswaByKota(Kota).ToList();
            }
            return result;
        }
    }

    public class listkota
    {
        public string kota;
    }
}
