﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Databaseconnection3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MahasiswaRepository repo = new MahasiswaRepository();
            // dataGridView1.DataSource = repo.GetMahasiswaByKota(textBox1.Text);
            string datafilter = textBox1.Text;
            string[] datafilter2 = datafilter.Split(',');
            List<string> datakota = new List<string>();
            //datakota = datafilter2.ToList();
            for (int i = 0; i < datafilter2.Length; i++)
            {
                datakota.Add(datafilter2[i]);
            }

            //foreach(var x in datafilter2)
            //{
            //    listkota datakota2 = new listkota();
            //    datakota2.kota = x;
            //    datakota.Add(datakota2);
            //}
            dataGridView1.DataSource = repo.GetMahasiswaByKota(datakota);
            //dataGridView1.DataSource = repo.GetMahasiswaByKotaProc(textBox1.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MahasiswaRepository tambah = new MahasiswaRepository();
            var data = new Mahasiswa()
            {
                Nama = textBox2.Text,Kota = textBox3.Text
            };
            tambah.AddData(data);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MahasiswaRepository edit = new MahasiswaRepository();
            edit.EditData(Convert.ToInt32(textBox6.Text), textBox5.Text, textBox4.Text);
            MessageBox.Show("Data sudah di update!");
        }

        private void button5_Click(object sender, EventArgs e)
        {

            MahasiswaRepository edit = new MahasiswaRepository();
            edit.DeleteData(Convert.ToInt32(textBox7.Text));
            MessageBox.Show("Data sudah di delete!");
        }
    }
}
