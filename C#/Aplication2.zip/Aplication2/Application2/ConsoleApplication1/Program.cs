﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    public interface IGeometri
    {
        void CetakLuas(int panjang, int lebar);
    }

    class Program
    {
        static void Main(string[] args)
        {
            DrawObject[] dObj = new DrawObject[4];
            dObj[0] = new Line();
            dObj[1] = new Circle();
            dObj[2] = new Square();
            dObj[3] = new DrawObject();

            foreach (var item in dObj)
            {
                item.Draw();
                if(item is Line)
                {
                    var line = (Line)item;
                    line.draw2();
                }
            }

            IGeometri persegipanjang = new Line();
            IGeometri kotak = new Square();
            IGeometri lingkaran = new Circle();

            CetakLuas(persegipanjang);
            CetakLuas(kotak);
            CetakLuas(lingkaran);
            Console.ReadLine();
        }

        private static void CetakLuas(IGeometri test)
        {
            test.CetakLuas(5, 6);
        }
    }


     public class DrawObject
    {
        public virtual void Draw()
        {
            Console.WriteLine("tester");
        }

       
    }
    public class Line : DrawObject,IGeometri
    {
        public override void Draw()
        {
            Console.WriteLine("1");
        }
        public void draw2()
        {
            Console.WriteLine("xxx");
            Draw();
        }
        public void CetakLuas(int panjang, int lebar)
        {
            int luas = panjang * lebar;
            Console.WriteLine("Luas Persegi Panjang = " + luas);
        }
    }
    public class Circle : DrawObject, IGeometri
    {
        public override void Draw()
        {
            Console.WriteLine("2");
        }
        public void CetakLuas(int panjang, int lebar)
        {
            double luas = 3.14 * Convert.ToDouble(panjang*panjang);
            Console.WriteLine("Luas Lingkaran = " + luas);
        }

    }
    public class Square : DrawObject, IGeometri
    {
        public override void Draw()
        {
            Console.WriteLine("3");
        }
        public void CetakLuas(int panjang, int lebar)
        {
            double luas = panjang*panjang;
            Console.WriteLine("Luas kotak = " + luas);
        }


    }
}
