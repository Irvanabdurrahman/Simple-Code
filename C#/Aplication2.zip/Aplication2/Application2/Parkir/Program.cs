﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parkir
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Parkir> ListOfParkir = new List<Parkir>();

            string ulang = "y";
            while (ulang.ToLower() == "y")
            {
                Console.Clear();
                Console.WriteLine("\n\n=============================");
                Console.WriteLine("        MENU UTAMA           ");
                Console.WriteLine("=============================");
                Console.WriteLine("1. Parkir Masuk");
                Console.WriteLine("2. Parkir Keluar");
                Console.WriteLine("3. Cetak Parkir");
                Console.WriteLine("7. Keluar");
                Console.WriteLine("\nPilihan Anda?");
                string menu2 = Console.ReadLine();
                switch (menu2)
                {

                    case "1":
                        {
                            TiketProcess tktprocess = new TiketProcess();
                            tktprocess.TiketMasuk(ListOfParkir);
                            break;
                        }

                    case "2":
                        {
                            TiketProcess tktprocess = new TiketProcess();
                            tktprocess.TiketKeluar(ListOfParkir);
                            break;
                        }

                    case "3":
                        {
                            TiketProcess tktprocess = new TiketProcess();
                            tktprocess.CetakTiket2(ListOfParkir);
                            break;
                        }
                  
                    case "7":
                        {
                            ulang = "n";
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("MENU TIDAK TERDAFTAR");
                            break;
                        }
                }

                if (ulang != "n")
                {
                    Console.WriteLine("Ulang lagi? (y/Y)");
                    ulang = Console.ReadLine();
                }
            }
        }
    }
    public class Parkir
    {
        public string PlatNo;
        public string JamMasuk;
        public string JamKeluar;
        public string TotalJam;
    }
}
