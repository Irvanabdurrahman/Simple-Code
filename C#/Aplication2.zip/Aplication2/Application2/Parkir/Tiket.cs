﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parkir
{
    class TiketProcess
    {
        public void TiketMasuk(List<Parkir> ListOfTkt)
        {
            Console.Clear();
            Console.WriteLine("Masukan jumlah data : ");
            int jumlahdata = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < jumlahdata; i++)
            {
                Console.Clear();
                Parkir tkt2 = new Parkir();
                Console.WriteLine("Plat no           :");
                tkt2.PlatNo = Console.ReadLine();
                Console.WriteLine("Jam Masuk (HH:MM) :");
                tkt2.JamMasuk = Console.ReadLine();
                ListOfTkt.Add(tkt2);


                Console.WriteLine("-------------------------------------------");
            }
        }
        public void TiketKeluar(List<Parkir> ListOfTkt)
        {
            Console.Clear();
            CetakTiket(ListOfTkt);
            Console.WriteLine("\nMasukan Nomer Mobil     : ");
            string nomobil = Console.ReadLine();
            Parkir tktid = CariTiket(nomobil, ListOfTkt);
            Console.WriteLine("Masukan Jam Keluar(HH:MM) : ");
            string jamkeluar = Console.ReadLine();
            tktid.JamKeluar = jamkeluar;
        }
        public void CetakTiket(List<Parkir> ListOfTkt)
        {
            Console.Clear();
            Console.WriteLine("\n===================================================");
            Console.WriteLine("PlatNo\t\tJam Masuk");
            Console.WriteLine("===================================================");

            foreach (var tktitem in ListOfTkt)
            {
                if (string.IsNullOrEmpty(tktitem.JamKeluar))
                {
                    Console.WriteLine("" + tktitem.PlatNo+ "\t\t" + tktitem.JamMasuk );
                    Console.WriteLine("------------------------------------------------");
                }
            }
        }
        public void CetakTiket2(List<Parkir> ListOfTkt)
        {
            Console.Clear();
            Console.WriteLine("\n==========================================================");
            Console.WriteLine("PlatNo\t\tJam Masuk\tJam Keluar\tTotal Jam");
            Console.WriteLine("==========================================================");

            foreach (var tktitem in ListOfTkt)
            {
                if (tktitem.JamKeluar != "")
                {

                    int tahun = Convert.ToInt32(DateTime.Now.Year);
                    int bulan = Convert.ToInt32(DateTime.Now.Month);
                    int hari = Convert.ToInt32(DateTime.Now.Day);

                    string[] jammasuk = tktitem.JamMasuk.Split(':');
                    int jam = Convert.ToInt32(jammasuk[0]);
                    int menit = Convert.ToInt32(jammasuk[1]);
                    int detik = 0;
                    DateTime entry = new DateTime(tahun, bulan, hari, jam, menit, detik);
                    
                    string[] jamkeluar = tktitem.JamKeluar.Split(':');
                    int jam2 = Convert.ToInt32(jamkeluar[0]);
                    int menit2 = Convert.ToInt32(jamkeluar[1]);
                    int detik2 = 0;
                    DateTime outtime = new DateTime(tahun, bulan, hari, jam2, menit2, detik2);

                    TimeSpan lamaparkir = outtime.Subtract(entry);

                    Console.WriteLine("" + tktitem.PlatNo + "\t\t" + tktitem.JamMasuk + "\t\t" + tktitem.JamKeluar + "\t\t" + lamaparkir.Hours + " jam,"+ lamaparkir.Minutes +" menit");
                    Console.WriteLine("------------------------------------------------------------");
                }
            }
        }
         private Parkir CariTiket(String PlatNo, List<Parkir> ListOfTkt)
        {
            Parkir tktid = new Parkir();
            foreach (var item in ListOfTkt)
            {
                if(PlatNo == item.PlatNo)
                {
                    return item;
                }
            }
            return new Parkir();
        }
        private Parkir CariTiket2(List<Parkir> ListOfTkt)
       {
           Parkir tktid = new Parkir();
           foreach (var item in ListOfTkt)
           {
               if (item.JamKeluar=="")
               {
                   return item;
               }
           }
           return new Parkir();
       }
        }
    }

