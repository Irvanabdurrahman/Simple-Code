﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Data.Sql;


namespace DatabaseConnection
{
    public partial class Form1 : Form
    {
        string constr = @"Data Source=localhost;Initial Catalog=training;User ID=sa;Password=romansy1";
        SqlConnection conn;
        public Form1()
        {
            InitializeComponent();
            conn = new SqlConnection(constr);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand sqlCom = new SqlCommand();
            sqlCom.Connection = conn;
            sqlCom.CommandType = CommandType.Text;
            sqlCom.CommandText = "select * from mahasiswa";
            DataSet ds = new DataSet();
            SqlDataAdapter sqlAdp = new SqlDataAdapter(sqlCom);
            sqlAdp.Fill(ds, "tMahasiswa");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "tMahasiswa";
            conn.Close();
        }
    }
}
