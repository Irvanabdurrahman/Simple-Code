﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatabaseConnection2
{
    class MahasiswaRepository
    {
        public List<Mahasiswa> GetMahasiswaByKota(string Kota)
        {

        }


    }
}
