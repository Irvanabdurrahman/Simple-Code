﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Query
{
    public class Mahasiswa
    {
        public int ID { get; set; }
        public string Nama { get; set; }
        public string JenisKelamin { get; set; }
        public string Kota { get; set; }
        public int Nilai { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {
            List<Mahasiswa> data = new List<Mahasiswa>();
            data.Add(new Mahasiswa() { ID = 1, Nama = "Joko", JenisKelamin = "L", Kota = "Bekasi", Nilai=70 });
            data.Add(new Mahasiswa() { ID = 2, Nama = "Susilo", JenisKelamin = "L", Kota = "Depok", Nilai = 50 });
            data.Add(new Mahasiswa() { ID = 3, Nama = "Bambang", JenisKelamin = "L", Kota = "Bandung", Nilai = 60 });
            data.Add(new Mahasiswa() { ID = 4, Nama = "Ahok", JenisKelamin = "L", Kota = "Bekasi", Nilai = 80 });
            data.Add(new Mahasiswa() { ID = 5, Nama = "Yudha", JenisKelamin = "L", Kota = "Bekasi", Nilai = 90 });
            data.Add(new Mahasiswa() { ID = 6, Nama = "Cici", JenisKelamin = "P", Kota = "Jogja", Nilai = 100 });
            data.Add(new Mahasiswa() { ID = 7, Nama = "Cucu", JenisKelamin = "P", Kota = "Bekasi", Nilai = 10 });
            data.Add(new Mahasiswa() { ID = 8, Nama = "Cece", JenisKelamin = "P", Kota = "Jakarta", Nilai = 30 });
            data.Add(new Mahasiswa() { ID = 9, Nama = "Coco", JenisKelamin = "P", Kota = "Bekasi", Nilai = 60 });
            data.Add(new Mahasiswa() { ID = 10, Nama = "Caca", JenisKelamin = "L", Kota = "Banten", Nilai = 70 });

            //untuk mencari query yang jenis kelamin nya L
            Console.WriteLine("LAKI-LAKI");
            var ListMhsLaki = data.Where(x => x.JenisKelamin == "L").OrderByDescending(x=>x.Nama).ThenBy(x=>x.ID);
            foreach(var item in ListMhsLaki)
            {
                Console.WriteLine(item.ID + "\t" + item.Nama + "\t" + item.JenisKelamin + "\t" + item.Kota);
            }

            //Order by typeo 2
            var ListMhsLaki2 = from mhs in data
                               where mhs.JenisKelamin =="L"
                               orderby mhs.Nama ascending
                               select mhs;
            Console.WriteLine("LAKI-LAKI v2");
            foreach (var item in ListMhsLaki2)
            {
                Console.WriteLine(item.ID + "\t" + item.Nama + "\t" + item.JenisKelamin + "\t" + item.Kota);
            }
            
            Console.WriteLine("PEREMPUAN");
            //untuk mencari query yang jenis kelamin nya P
            var ListMhsPere = data.Where(x => x.JenisKelamin == "P");
            foreach (var item in ListMhsPere)
            {
                Console.WriteLine(item.ID + "\t" + item.Nama + "\t" + item.JenisKelamin + "\t" + item.Kota);
            }

            //untuk count
            Console.WriteLine("Count");
            var TotalLakiPere = data.GroupBy(x => x.JenisKelamin).Select(g => new
                {
                    JenisKelamin = g.Key,
                    Jumlah = g.Count()
                });
            foreach (var item in TotalLakiPere)
            {
                Console.WriteLine(item.JenisKelamin + "\t" + item.Jumlah);
            }

            //untuk update nilai
            foreach (var item in data.Where(x=>x.Kota=="Jakarta"))
            {
                item.Nilai = 100;
            }

            Console.ReadLine();

        }
    }
}
