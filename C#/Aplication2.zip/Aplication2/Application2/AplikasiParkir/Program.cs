﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AplikasiParkir
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
    public class Parkir
    {
        public string PlatNo;
        public DateTime JamMasuk;
        public DateTime JamKeluar;
        public string TotalJam;
    }

    public class ParkirList
    {
        List<Parkir> ListOfParkir = new List<Parkir>();
    }
    public class ParkirProcess 
    {

        List<Parkir> ListOfParkir = new List<Parkir>();
        public void TiketMasuk(string NoPol)
        {
            
            Parkir simpandata = new Parkir();
            simpandata.PlatNo = NoPol;
            simpandata.JamMasuk = DateTime.Now;
            ListOfParkir.Add(simpandata);
            MessageBox.Show("Data Tersimpan!");
        }
        public Parkir CariTiket(string NoPol)
        {

            //Parkir tktid = new Parkir();
            foreach (var item in ListOfParkir)
            {
                if (NoPol == item.PlatNo)
                {
                    return item;
                }
            }
            return new Parkir();
        }
        public Parkir HitungWaktu(DateTime JamKeluar)
        {

            //Parkir tktid = new Parkir();
            foreach (var item in ListOfParkir)
            {
                if (NoPol == item.PlatNo)
                {
                    return item;
                }
            }
            return new Parkir();
        }
    }
}
