﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class Pegawai
    {
        public struct PegawaiDetail
        {
            public string NIP;
            public string Nama;
        }

    }
}
