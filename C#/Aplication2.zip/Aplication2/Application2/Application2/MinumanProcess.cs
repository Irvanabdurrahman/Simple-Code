﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class MinumanProcess
    {
        public void inputMinuman(List<MinumanDetail> ListOfMinuman)
        {
            Console.Clear();
            Console.WriteLine("Masukan jumlah data : ");
            int jumlahdata = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < jumlahdata; i++)
            {
                MinumanDetail minuman2 = new MinumanDetail();
                Console.WriteLine("ID Minuman           :");
                minuman2.IDMinuman = Console.ReadLine();
                Console.WriteLine("Nama Minuman         :");
                minuman2.Nama = Console.ReadLine();
                Console.WriteLine("Harga Minuman        :");
                minuman2.Harga = Convert.ToInt32(Console.ReadLine());
                ListOfMinuman.Add(minuman2);
                Console.WriteLine("-------------------------------------------");
            }

        }
        public void cetakMinuman(List<MinumanDetail> ListOfMinuman)
        {
            Console.Clear();
            Console.WriteLine("\n====================================================");
            Console.WriteLine("ID\tNAMA\t\tHARGA");
            Console.WriteLine("====================================================");
            foreach (var minuman in ListOfMinuman)
            {

                Console.WriteLine("" + minuman.IDMinuman + "\t" + minuman.Nama + "\t\t" + minuman.Harga);
                Console.WriteLine("-----------------------------------------------");
            }
        }
    }
}
