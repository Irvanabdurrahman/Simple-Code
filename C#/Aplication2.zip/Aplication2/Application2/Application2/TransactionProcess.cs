﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class TransactionProcess
    {
        public void inputMakanan(List<Transaksi> ListOfTrans,List<MakananDetail> ListOfmkn,List<MinumanDetail> ListOfmnm,List<Bayar> ListOfbyr)
        {
            Console.Clear();
            Bayar byr = new Bayar();

            Console.WriteLine("\n====================================================");
            Console.WriteLine("ID\tNAMA\t\tHARGA");
            Console.WriteLine("===================================================");
            foreach (var makanan in ListOfmkn)
            {

                Console.WriteLine("" + makanan.IDMakanan + "\t" + makanan.Nama + "\t\t" + makanan.Harga);
                Console.WriteLine("------------------------------------------------");
            }
            foreach (var minuman in ListOfmnm)
            {

                Console.WriteLine("" + minuman.IDMinuman + "\t" + minuman.Nama + "\t\t" + minuman.Harga);
                Console.WriteLine("------------------------------------------------");
            }


            Console.WriteLine("\nMasukan Nomor Meja : ");
            string mejaid = Console.ReadLine();

            string cetak = "n";
            while(cetak.ToLower()=="n")
            {

                Transaksi trans = new Transaksi();
                trans.MejaID = mejaid;
                Console.WriteLine("Masukan ID Pesanan : ");
                trans.IDPaket = Console.ReadLine();
                Console.WriteLine("Masukan Qty : ");
                trans.Jumlah = Convert.ToInt32(Console.ReadLine());
                ListOfTrans.Add(trans);
                Console.WriteLine("===============================================");
                Console.WriteLine("\n\nHitung & Cetak Transaksi?(Y/N)");
                cetak = Console.ReadLine();
            }

            Console.Clear();
            int grand = 0;
            Console.WriteLine("\n\nTagihan Untuk Meja : "+ mejaid);
            Console.WriteLine("========================================================");
            Console.WriteLine("Makanan/Minuman\t\tQTY\t\tHARGA");
            Console.WriteLine("========================================================");
            foreach (var trans2 in ListOfTrans)
            {
                if(trans2.MejaID==mejaid)
                {
                    string nama = string.Empty;
                    int harga = 0;
                    int total = 0;
                    foreach (var makanan in ListOfmkn)
                    {
                        if(makanan.IDMakanan==trans2.IDPaket)
                        {
                            nama = makanan.Nama;
                            harga = makanan.Harga;
                        }
                        
                    }
                    if(nama=="")
                    {
                        foreach (var minuman in ListOfmnm)
                        {
                            if (minuman.IDMinuman == trans2.IDPaket)
                            {
                                nama = minuman.Nama;
                                harga = minuman.Harga;
                            }

                        }
                    }
                    total = harga * trans2.Jumlah;
                    grand = grand + total;
                    Console.WriteLine("" + nama + "\t\t" + trans2.Jumlah + "\t" + total);
                    Console.WriteLine("--------------------------------------------------------");
                }
            }

            Console.WriteLine("Total    : " + grand);
            Console.WriteLine("--------------------------------------------------------");

            Console.WriteLine("Masukan Uang Yang Dibayar : ");
            int Bayar = Convert.ToInt32(Console.ReadLine());
            int kembalian = Bayar - grand;
            Console.WriteLine("Kembalian                 :  "+ kembalian);
            byr.MejaID = mejaid;
            byr.Total = Bayar;
            byr.Kembalian = kembalian;
            ListOfbyr.Add(byr);
            Console.ReadLine();
        }

    }
}
