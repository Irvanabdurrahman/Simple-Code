﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class Program
    {
        static void Main(string[] args)
        {
            List<MakananDetail> ListOfMakanan = new List<MakananDetail>();
            List<MinumanDetail> ListOfMinuman = new List<MinumanDetail>();
            List<Transaksi> ListOfTransaksi = new List<Transaksi>();
            List<Bayar> ListOfBayar = new List<Bayar>();

            string ulang = "y";
            while (ulang.ToLower() == "y")
            {
                Console.Clear();
                Console.WriteLine("\n\n=============================");
                Console.WriteLine("        MENU UTAMA           ");
                Console.WriteLine("=============================");
                Console.WriteLine("1. Input Makanan");
                Console.WriteLine("2. Input Minuman");
                Console.WriteLine("3. Cetak Makanan");
                Console.WriteLine("4. Cetak Minuman");
                Console.WriteLine("5. Input Transaksi");
                Console.WriteLine("7. Keluar");
                Console.WriteLine("\nPilihan Anda?");
                string menu2 = Console.ReadLine();
                switch (menu2)
                {

                    case "1":
                        {
                            MakananProcess mknprocess = new MakananProcess();
                            mknprocess.inputMakanan(ListOfMakanan);
                            break;
                        }

                    case "2":
                        {
                            MinumanProcess mnmprocess = new MinumanProcess();
                            mnmprocess.inputMinuman(ListOfMinuman);
                            break;
                        }

                    case "3":
                        {
                            MakananProcess mknprocess = new MakananProcess();
                            mknprocess.CetakMakanan(ListOfMakanan);
                            break;
                        }
                    case "4":
                        {
                            MinumanProcess mnmprocess = new MinumanProcess();
                            mnmprocess.cetakMinuman(ListOfMinuman);
                            break;
                        }
                    case "5":
                        {
                            TransactionProcess trsprocess = new TransactionProcess();
                            trsprocess.inputMakanan(ListOfTransaksi, ListOfMakanan, ListOfMinuman, ListOfBayar);
                            break;
                        }
                    case "7":
                        {
                            ulang = "n";
                            break;
                        }
                    default:
                        {
                            Console.WriteLine("MENU TIDAK TERDAFTAR");
                            break;
                        }
                }

                if (ulang != "n")
                {
                    Console.WriteLine("Ulang lagi? (y/Y)");
                    ulang = Console.ReadLine();
                }
            }
        }
    }


    public class MakananDetail
    {
        public string IDMakanan;
        public string Nama;
        public int Harga;
    }
    public class MinumanDetail
    {
        public string IDMinuman;
        public string Nama;
        public int Harga;
    }
    public class Transaksi
    {
        public string MejaID;
        public string IDPaket;
        public int Jumlah;
        public int TotHarga;
    }
    public class Bayar
    {
        public string MejaID;
        public int Total;
        public int Kembalian;
    }
}
