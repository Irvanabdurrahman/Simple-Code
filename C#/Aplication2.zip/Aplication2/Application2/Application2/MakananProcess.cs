﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class MakananProcess
    {
        public void inputMakanan(List<MakananDetail> ListOfMakanan)
        {
            Console.Clear();
            Console.WriteLine("Masukan jumlah data : ");
            int jumlahdata = Convert.ToInt32(Console.ReadLine());

            for (int i = 0; i < jumlahdata; i++)
            {
                MakananDetail makanan2 = new MakananDetail();
                Console.WriteLine("ID Makanan           :");
                makanan2.IDMakanan = Console.ReadLine();
                Console.WriteLine("Nama Makanan         :");
                makanan2.Nama = Console.ReadLine();
                Console.WriteLine("Harga Makanan        :");
                makanan2.Harga = Convert.ToInt32(Console.ReadLine());
                ListOfMakanan.Add(makanan2);


                Console.WriteLine("-------------------------------------------");
            }

        }
        public void CetakMakanan(List<MakananDetail> ListOfMakanan)
        {
            Console.Clear();
            Console.WriteLine("\n===================================================");
            Console.WriteLine("ID\tNAMA\t\tHARGA");
            Console.WriteLine("===================================================");
            foreach (var makanan in ListOfMakanan)
            {

                Console.WriteLine("" + makanan.IDMakanan + "\t" + makanan.Nama + "\t\t" + makanan.Harga);
                Console.WriteLine("-----------------------------------------");
            }
        }
    }
}
