﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RumahMakan
{
    public partial class Form1 : Form
    {
        List<MakananDetail> LOMakanan = new List<MakananDetail>();
        List<MinumanDetail> LOMinuman = new List<MinumanDetail>();
        List<Transaksi> LOTran = new List<Transaksi>();
        int totalharga = 0;


        public Form1()
        {



            InitializeComponent();

            LOMakanan.Add(new MakananDetail() { IDMakanan = "M01", Nama = "Nasi Goreng", Harga = 15000 });
            LOMakanan.Add(new MakananDetail() { IDMakanan = "M02", Nama = "Mie Goreng", Harga = 16000 });
            LOMakanan.Add(new MakananDetail() { IDMakanan = "M03", Nama = "Kwetiaw Goreng", Harga = 18000 });
            LOMakanan.Add(new MakananDetail() { IDMakanan = "M04", Nama = "Bihun Goreng", Harga = 12000 });
            LOMakanan.Add(new MakananDetail() { IDMakanan = "M05", Nama = "capcay Goreng", Harga = 10000 });

            LOMinuman.Add(new MinumanDetail() { IDMinuman = "N01", Nama = "Teh", Harga = 5000 });
            LOMinuman.Add(new MinumanDetail() { IDMinuman = "N02", Nama = "Kopi", Harga = 7000 });
            LOMinuman.Add(new MinumanDetail() { IDMinuman = "N03", Nama = "Susu", Harga = 7000 });
            LOMinuman.Add(new MinumanDetail() { IDMinuman = "N04", Nama = "Air", Harga = 3000 });
            LOMinuman.Add(new MinumanDetail() { IDMinuman = "N05", Nama = "Jus", Harga = 10000 });

            for (int i = 1; i <= 5; i++)
            {
                comboBox1.Items.Add(i);
            }

            foreach (var item in LOMakanan)
            {
                comboBox2.Items.Add(item.IDMakanan + "-" + item.Nama + "-" + item.Harga);
            }
            foreach (var item in LOMinuman)
            {
                comboBox3.Items.Add(item.IDMinuman + "-" + item.Nama + "-" + item.Harga);
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string meja = Convert.ToString(comboBox1.SelectedItem);
            string makanan = Convert.ToString(comboBox2.SelectedItem);
            string minuman = Convert.ToString(comboBox3.SelectedItem);
            
            string[] itemmakanan = makanan.Split('-');
            int hargamakanan = Convert.ToInt32(itemmakanan[2]);
            string[] itemminuman = minuman.Split('-');
            int hargaminuman = Convert.ToInt32(itemminuman[2]);

            MakananProcess pro = new MakananProcess();
            pro.AddTrans(meja, LOTran);
            if(string.IsNullOrEmpty(makanan)==false)
            {
                textBox1.Text = textBox1.Text + makanan + ", jumlah : " + Qty1.Text + Environment.NewLine;
                totalharga = totalharga + pro.HitungMakanan(hargamakanan, Convert.ToInt32(Qty1.Text));
                //MakananDetail datamakan = pro.CariMakanan(itemmakanan[0], LOMakanan);
                pro.AddTrans1(meja, itemminuman[0], Qty1.Text, LOTran,LOMakanan);
            }
            if (string.IsNullOrEmpty(minuman) == false)
            {
                textBox1.Text = textBox1.Text + minuman + ", jumlah : " + Qty2.Text + Environment.NewLine;
                totalharga = totalharga + pro.HitungMakanan(hargaminuman, Convert.ToInt32(Qty2.Text));
                pro.AddTrans2(meja, itemminuman[0], Qty1.Text, LOTran,LOMinuman);
            }

            label5.Text = Convert.ToString(totalharga);


        }

        private void button2_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox2.Text)==false)
            {
                int kembalian = Convert.ToInt32(textBox2.Text) - totalharga;
                textBox3.Text = Convert.ToString(kembalian);
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MakananProcess pro = new MakananProcess();
            var datatrans = pro.CariMeja(Convert.ToString(comboBox1.SelectedItem), LOTran);
            foreach(var item in datatrans)
            {

            }
        }
    }
}
