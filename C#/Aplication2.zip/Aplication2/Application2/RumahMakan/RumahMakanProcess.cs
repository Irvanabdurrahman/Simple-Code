﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RumahMakan
{
    class MakananProcess
    {

        public int HitungMakanan(int harga, int qty)
        {
            int total = harga * qty;
            return total;
        }
        public MakananDetail CariMakanan(string ID,List<MakananDetail> mkn)
        {
            var datamakan = (from mkn2 in mkn
                            where mkn2.IDMakanan == ID
                             select mkn2).FirstOrDefault();
            return datamakan;
           // return new Transaksi();
        }
        public MinumanDetail CariMinuman(string ID, List<MinumanDetail> mnm)
        {
            var dataminum = (from mnm2 in mnm
                             where mnm2.IDMinuman == ID
                             select mnm2).FirstOrDefault();
            return dataminum;
            // return new Transaksi();
        }
        public void AddTrans(string nomeja, List<Transaksi> trans)
        {
            Transaksi mkan = new Transaksi();
            mkan.MejaID = nomeja;;
            trans.Add(mkan);
        }
        public void AddTrans1(string nomeja, string makanan, string qty, List<Transaksi> trans, List<MakananDetail> mkn)
        {
            var datamakan = (from mkn2 in mkn
                             where mkn2.IDMakanan == makanan
                             select mkn2).FirstOrDefault();
            
            var datatrans = (from trans2 in trans
                             where trans2.MejaID == nomeja
                             select trans2).FirstOrDefault();
            datatrans.Makanan.Add(datamakan);
            datatrans.QtyMakanan =  Convert.ToInt32(qty);
        }
        
        public void AddTrans2(string nomeja, string minuman, string qty, List<Transaksi> trans, List<MinumanDetail> mkn)
        {
            var dataminuman = (from mkn2 in mkn
                             where mkn2.IDMinuman == minuman
                             select mkn2).FirstOrDefault();
            
            var datatrans = (from trans2 in trans
                             where trans2.MejaID == nomeja
                             select trans2).FirstOrDefault();
            datatrans.Minuman.Add(dataminuman);
            datatrans.QtyMinuman =  Convert.ToInt32(qty);

        public Transaksi CariMeja(String Meja, List<Transaksi> trans)
        {
            var ListMeja = (from trans2 in trans
                           where trans2.MejaID == Meja
                           select trans2).FirstOrDefault();
            return ListMeja;
        }
    }
    public class MakananDetail
    {
        public string IDMakanan;
        public string Nama;
        public int Harga;

        
    }
    public class MinumanDetail
    {
        public string IDMinuman;
        public string Nama;
        public int Harga;
    }
    public class Transaksi
    {
        public string MejaID;
        public List<MakananDetail> Makanan;
        public int QtyMakanan;
        public List<MinumanDetail> Minuman;
        public int QtyMinuman;
        public int TotHarga;
    }

}
