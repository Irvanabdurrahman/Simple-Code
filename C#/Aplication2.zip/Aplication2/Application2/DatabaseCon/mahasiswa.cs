﻿namespace DatabaseCon {
    
    
    public partial class mahasiswa {
    }
}

namespace DatabaseCon.mahasiswaTableAdapters {
    
    
    public partial class Mahasiswa1TableAdapter {
    }
}
