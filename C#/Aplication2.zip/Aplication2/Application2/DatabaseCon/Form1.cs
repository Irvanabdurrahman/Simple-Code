﻿using DatabaseCon.mahasiswaTableAdapters;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DatabaseCon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            string Kota = textBox1.Text;
            mahasiswa ds = new mahasiswa();
            Mahasiswa1TableAdapter data1 = new Mahasiswa1TableAdapter();
            List<Mhs> ListNama = new List<Mhs>();
            var dt = data1.GetDataByKota(Kota);
            for(int i=0;i<dt.Rows.Count;i++)
            {
                DataRow dtRow = dt.Rows[i];
                ListNama.Add(new Mhs() { Nama = dtRow.ItemArray[1].ToString() });

            }
            dataGridView1.DataSource = ListNama;
            //dataGridView1.DataSource = data1.GetDataByKota(Kota);

        }

        //private void Form1_Load(object sender, EventArgs e)
        //{
        //    // TODO: This line of code loads data into the 'mahasiswa.Mahasiswa1' table. You can move, or remove it, as needed.
        //    this.mahasiswa1TableAdapter.Fill(this.mahasiswa.Mahasiswa1);

        //}
    }
    public class Mhs
    {
        public string Nama {get; set;}
    }
}
