﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void hitung_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Circle")
            {
                double luas = 3.14 * Convert.ToDouble(panjang.Text);
                label4.Text = Convert.ToString(luas);
            }
            else if (comboBox1.Text == "Square")
            {
                double luas = Convert.ToDouble(panjang.Text) * Convert.ToDouble(panjang.Text);
                label4.Text = Convert.ToString(luas);
            }
            else if (comboBox1.Text == "Box")
            {
                int luas = Convert.ToInt32(panjang.Text) * Convert.ToInt32(lebar.Text);
                label4.Text = Convert.ToString(luas);
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text=="Circle")
            {
                label1.Text = "Diameter";
                label2.Text = "";
                lebar.Visible = false;
            }
            else if (comboBox1.Text == "Square")
            {
                label1.Text = "Sisi";
                label2.Text = "";
                lebar.Visible = false;
            }
            else if (comboBox1.Text == "Box")
            {
                label1.Text = "Panjang";
                label2.Text = "Lebar";
                panjang.Visible = true;
                lebar.Visible = true;
            }
        }
    }
}
