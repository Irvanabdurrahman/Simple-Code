﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class SeaFood : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
             decimal select1 = 0;
            decimal select2 = 0;
            decimal select3 = 0;
             decimal select4 = 0;
             decimal select5 = 0;
             decimal select6 = 0;
            decimal totalTagihan = 0;
            decimal member = 0;
            decimal potonganMember = 0;
            decimal amountDiskon = 0;
            decimal payMethod = 0;
            decimal totalMethod = 0;
            decimal amountTotal = 0;
            decimal bayar = 0;

            if (CheckBox1.Checked)
            {
                select1 = (Convert.ToInt32(TextBox1.Text) * 25000);
            }

            if (CheckBox2.Checked)
            {
                select2 = (Convert.ToInt32(TextBox2.Text) * 17500);
            }

            if (CheckBox3.Checked)
            {
                select3 = (Convert.ToInt32(TextBox3.Text) * 15000);
            }

            if (CheckBox4.Checked)
            {
                select4 = (Convert.ToInt32(TextBox4.Text) * 5000);
            }

            if (CheckBox5.Checked)
            {
                select5 = (Convert.ToInt32(TextBox5.Text) * 18000);
            }

            if (CheckBox6.Checked)
            {
                select6 = (Convert.ToInt32(TextBox6.Text) * 22000);
            }

            decimal.TryParse(RadioButtonList1.SelectedValue, out member);
            totalTagihan = select1 + select2 + select3 + select4 + select5 + select6;

            if (member.ToString() != "0")
            {
                if (member.ToString() == "0.15")
                {
                    potonganMember = (totalTagihan * Convert.ToDecimal(0.15));
                    amountDiskon = totalTagihan - potonganMember;
                }
                else if (member.ToString() == "0.1")
                {
                    potonganMember = (totalTagihan * Convert.ToDecimal(0.1));
                    amountDiskon = totalTagihan - potonganMember;
                }
            }else
            {
                amountDiskon = totalTagihan;
            }

            decimal.TryParse(DropDownList1.SelectedValue, out payMethod);
           

            if (payMethod != 0)
            {
                totalMethod = amountDiskon * payMethod;
                amountTotal = amountDiskon + totalMethod;
            }
            else
            {
                amountTotal = amountDiskon;
            }



          
            txtTagihan.Text = amountTotal.ToString();
            bayar = (Convert.ToInt32(TextBox8.Text) - amountTotal);
            TextBox9.Text = bayar.ToString();
        }
    }
}