﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class CrossPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(Page.PreviousPage != null)
            {
                Label1.Text = ((TextBox)Page.PreviousPage.FindControl("TextBox1")).Text;
                var data = ((TextBox)Page.PreviousPage.FindControl("TextBox1"));
                Panel1.Controls.Add(data);
            }else
            {
                Label1.Text = "aaa";
            }


        }
    }
}