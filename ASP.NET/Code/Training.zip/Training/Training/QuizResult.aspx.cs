﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class QuizResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            var data = ((RadioButtonList)Page.PreviousPage.FindControl("RadioButtonList1")).SelectedValue;
            Label3.Text = data;
            Label1.Text = "Value";
            string no1 = "10";
           
            if (Convert.ToString(data) == "Value")
            {
                Label2.Text = no1;
            }else
            {
                Label2.Text = "0";
            }

            //no 2
            var jawaban2 = 0;
            var data1 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox1"));
            var data2 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox2"));
            var data3 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox3"));

            //jawaban2 = data1 + " - " + data2 + " - " + data3;

           // Label4.Text = Convert.ToString(jawaban2);
            Label5.Text = "C# dan VB.NET";
            string no2 = "10";

           if ((data1.Checked && data2.Checked) != data3.Checked)
            {
                Label6.Text = no2;
            }
           else
           {
                Label6.Text = "0";
            }


            //no 3
            var dataJ3 = ((RadioButtonList)Page.PreviousPage.FindControl("RadioButtonList2")).SelectedValue;
            Label7.Text = dataJ3;
            Label8.Text = "Class";
            string no3 = "10";

            if (Convert.ToString(dataJ3) == "Class")
            {
                Label9.Text = no3;
            }
            else
            {
                Label9.Text = "0";
            }

            //no 4
           /*var jawaban4 = 0;
            var dtJ41 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox4"));
            var dtJ42 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox5"));
            var dtJ43 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox6"));
            var dtJ44 = ((CheckBox)Page.PreviousPage.FindControl("CheckBox7"));
            */

            //jawaban2 = data1 + " - " + data2 + " - " + data3;

            // Label4.Text = Convert.ToString(jawaban2);
            /*Label10.Text = "Dapper dan Petapoco";
            string no4 = "10";

            if ((dtJ41.Checked && dtJ42.Checked) != (dtJ43.Checked && dtJ44.Checked))
            {
                Label12.Text = no4;
            }
            else
            {
                Label12.Text = "0";
            }*/
        }
    }
}