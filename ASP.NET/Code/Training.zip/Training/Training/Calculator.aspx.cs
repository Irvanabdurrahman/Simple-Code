﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class Calculator : System.Web.UI.Page
    {
        decimal txtSatu;
        decimal txtDua;
        decimal txtTiga;
        decimal txtEmpat;
        decimal txtLima;
        decimal txtEnam;
        decimal txtTujuh;
        decimal txtDelapan;
        decimal txtSembilan;
        decimal txtNol;
        decimal txtKoma;
        decimal hasilPlus;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void txt1_Click(object sender, EventArgs e)
        {
            txtSatu = 1;
            txtHasil.Text = txtSatu.ToString();
        }

        protected void txt2_Click(object sender, EventArgs e)
        {
            txtDua = 2;
            txtHasil.Text = txtDua.ToString();
        }

        protected void txtPlus_Click(object sender, EventArgs e)
        {
            Hidden1.Value = txtHasil.Text;
            Hidden2.Value = "+"; 
        }

        protected void txtSamaDengan_Click(object sender, EventArgs e)
        {
            decimal nilai1 = 0;
            decimal nilai2 = 0;
            decimal hasil = 0;
            decimal.TryParse(txtHasil.Text, out nilai1);
            decimal.TryParse(Hidden1.Value, out nilai2);

            hasil = nilai1 + nilai2;
            txtHasil.Text = hasil.ToString();
        }

        protected void txt3_Click(object sender, EventArgs e)
        {
            txtTiga = 3;
            txtHasil.Text = txtTiga.ToString();
        }

        protected void txt4_Click(object sender, EventArgs e)
        {
            txtEmpat = 4;
            txtHasil.Text = txtEmpat.ToString();
        }

        protected void txt5_Click(object sender, EventArgs e)
        {
            txtLima = 5;
            txtHasil.Text = txtLima.ToString();
        }

        protected void txt6_Click(object sender, EventArgs e)
        {
            txtEnam = 6;
            txtHasil.Text = txtEnam.ToString();
        }

        protected void txt7_Click(object sender, EventArgs e)
        {
            txtTujuh = 7;
            txtHasil.Text = txtTujuh.ToString();
        }

        protected void txt8_Click(object sender, EventArgs e)
        {
            txtDelapan = 8;
            txtHasil.Text = txtDelapan.ToString();
        }

        protected void txt9_Click(object sender, EventArgs e)
        {
            txtSembilan = 9;
            txtHasil.Text = txtSembilan.ToString();
        }

        protected void txt0_Click(object sender, EventArgs e)
        {
            txtNol = 0;
            txtHasil.Text = txtNol.ToString();
        }

        protected void txtClear_Click(object sender, EventArgs e)
        {
            txtHasil.Text = "0";
        }

        protected void txtTitik_Click(object sender, EventArgs e)
        {
            txtHasil.Text = txtHasil.Text + ",";
        }
    }
}