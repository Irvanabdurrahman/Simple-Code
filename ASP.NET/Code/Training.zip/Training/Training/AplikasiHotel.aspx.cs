﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class AplikasiHotel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var tglIn = DateTime.Parse(TextBox1.Text);
            var tglOut = DateTime.Parse(TextBox2.Text);
            var lamaInap = ((tglOut - tglIn).TotalDays);
           

            decimal hargaKamar = 0;
            decimal member = 0;
            decimal totalDiskon = 0;
            decimal totalBayar = 0;
            decimal totalKamar = 0;

            decimal.TryParse(DropDownList1.SelectedValue, out hargaKamar);
            decimal.TryParse(RadioButtonList1.SelectedValue, out member);
            totalBayar = (hargaKamar * Convert.ToDecimal(lamaInap));


            if (member.ToString() != "0")
            {
                if (Math.Floor(lamaInap) > 10)
                {
                    if (member.ToString() == "0.15")
                    {
                        totalDiskon = ((totalBayar * Convert.ToDecimal(member)) + 200000);
                    }
                    else if (member.ToString() == "0.1")
                    {
                        totalDiskon = ((totalBayar * Convert.ToDecimal(member)) + 100000);
                    }
                    else if(member.ToString() == "0.05")
                    {
                        totalDiskon = ((totalBayar * Convert.ToDecimal(member)) + 300000);
                    }
                    totalKamar = Convert.ToInt32(totalBayar) - Convert.ToInt32(totalDiskon);
                }
                else{
                    totalDiskon = Convert.ToInt32(totalBayar);
                }
            }else
            {
                totalDiskon = Convert.ToInt32(totalBayar);
            }

            
            TextBox3.Text = lamaInap.ToString();
            TextBox4.Text = totalDiskon.ToString();
            TextBox5.Text = totalKamar.ToString();

            string hasil = "";
            hasil = hasil + "<i>Jenis Kamar :</i> " + DropDownList1.SelectedValue  + "</br>";
            hasil = hasil + "<i>Member :</i> " + RadioButtonList1.SelectedValue + "</br>";
            hasil = hasil + "<i>Lama Menginap :</i> " + Math.Floor(lamaInap) + "</br>";
            hasil = hasil + "<i>Total Diskon :</i> " + totalDiskon + "</br>";
            Literal1.Text = hasil;
        }
    }
}