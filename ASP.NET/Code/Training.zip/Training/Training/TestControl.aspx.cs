﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Training
{
    public partial class TestControl : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void RadioButtonList1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var tglLahir = Calendar1.SelectedDate;
            var TotalUmur = ((DateTime.Now.Date - tglLahir).TotalDays / 365);
            var tglMasuk = DateTime.Parse(TextBox1.Text);
            var lamaBekerja = ((DateTime.Now.Date - tglMasuk).TotalDays / 365);
            string hasil = "";
            hasil = hasil + "<i>Nama :</i> " + TextBox2.Text + "</br>";
            hasil = hasil + "Perkerjaan : " + DropDownList1.SelectedValue + "</br>";
            hasil = hasil + "Jenis Kelamain : " + RadioButtonList1.SelectedValue + "</br>";
            if (CheckBox1.Checked)
            {
                hasil = hasil + "Status : Karyawan </br>";
            }
            hasil = hasil + "Umur : " + Math.Floor(TotalUmur) + " Tahun </br>";
            hasil = hasil + "Lama Bekerja : " + Math.Floor(lamaBekerja)  + " Tahun";
            Literal1.Text = hasil;
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}