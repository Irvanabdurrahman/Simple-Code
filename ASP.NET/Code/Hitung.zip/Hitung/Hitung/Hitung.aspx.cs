﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Hitung
{
    public partial class Hitung : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int Panjang = 0;
            int Lebar = 0;
            int Hasil = 0;

            int.TryParse(txtPanjang.Text, out Panjang);
            int.TryParse(txtLebar.Text, out Lebar);

            Hasil = Panjang * Lebar;

            txtHasil.Text = Hasil.ToString();

        }
    }
}