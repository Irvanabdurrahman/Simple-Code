﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplikasiHotel
{
    public partial class BookingPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //var dt = new parkirDataTableAdapters.Parkir_trxTableAdapter();
            var dt = new DataSet1TransaksiTableAdapters.TransaksiTableAdapter();
            var noKmar1 = DropDownList1.SelectedItem;
            var noKmar = DropDownList1.SelectedValue;
            var isMember = CheckBox1.Checked;

            int hargaKamar=0;
            if (noKmar == "1")
            {
                hargaKamar = 1000000;
            }else if (noKmar == "2")
            {
                hargaKamar = 800000;
            }
            else if (noKmar == "3")
            {
                hargaKamar = 500000;
            }
            else if (noKmar == "4")
            {
                hargaKamar = 300000;
            }

            dt.Insert(Convert.ToInt32(noKmar1), Convert.ToDateTime(TextBox1.Text), Convert.ToDateTime(TextBox2.Text), hargaKamar, true,TextBox3.Text, isMember,false,false);
            Response.Redirect("CheckinPage.aspx");
        }
    }
}