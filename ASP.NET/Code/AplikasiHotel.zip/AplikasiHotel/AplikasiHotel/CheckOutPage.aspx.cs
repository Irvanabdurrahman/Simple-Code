﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplikasiHotel
{
    public partial class CheckOutPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var getData = new DataSet1TransaksiTableAdapters.TransaksiTableAdapter();
            var kmr = Convert.ToInt32(TextBox1.Text);
            var noKamar = getData.GetDataBy(kmr);
            if (noKamar.Count > 0)
            {
                var kamar = noKamar.Rows[0];
                var tglMasuk = (DateTime)kamar["TglMasuk"];
                var tglKeluar = (DateTime)kamar["TglKeluar"];
                var pemesan = (string)kamar["NamaPemesan"];
                var harga = (decimal)kamar["HargaKamarTransaksi"];

                Label1.Text = pemesan;
                Label2.Text = Convert.ToString(tglMasuk);
                Label3.Text = Convert.ToString(tglKeluar);
                Label4.Text = Convert.ToString(harga);
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            var ckIn = new DataSet1TransaksiTableAdapters.TransaksiTableAdapter();
            var kmr = Convert.ToInt32(TextBox1.Text);
            var noKamar = ckIn.GetDataBy(kmr);
            ckIn.UpdateQuery1(kmr);
        }
    }
}