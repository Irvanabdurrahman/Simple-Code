﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplikasiHotel
{
    public partial class CheckinPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var getData = new DataSet1TransaksiTableAdapters.TransaksiTableAdapter();
            var kmr = Convert.ToInt32(TextBox1.Text);
            var noKamar = getData.GetDataBy(kmr);
            if (noKamar.Count > 0)
            {
                var kamar = noKamar.Rows[0];
                var tglMasuk = (DateTime)kamar["TglMasuk"];
                var tglKeluar = (DateTime)kamar["TglKeluar"];
                var pemesan = (string)kamar["NamaPemesan"];

                Label1.Text = Convert.ToString(tglMasuk);
                Label2.Text = Convert.ToString(tglKeluar);
                Label3.Text = pemesan;
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
           var ckIn = new DataSet1TransaksiTableAdapters.TransaksiTableAdapter();
            var kmr = Convert.ToInt32(TextBox1.Text);
            var noKamar = ckIn.GetDataBy(kmr);
            ckIn.UpdateQuery(kmr);
        }
    }
}