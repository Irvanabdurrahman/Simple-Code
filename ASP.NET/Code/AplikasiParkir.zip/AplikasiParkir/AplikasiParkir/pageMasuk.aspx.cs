﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplikasiParkir
{
    public partial class pageMasuk : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            var strPlatNo = ((TextBox)FormView1.FindControl("PlatNoTextBox")).Text;
            var strType = ((TextBox)FormView1.FindControl("Type_KendaraanTextBox")).Text;
        }
    }
}