﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace AplikasiParkir
{
    public partial class pageKeluar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          
            var dt = new parkirDataTableAdapters.Parkir_trxTableAdapter();
            var kendaraan = dt.GetDataBy(TextBox1.Text);
            if (kendaraan.Count > 0)
            {
                var kendaraanKeluar = kendaraan.Rows[0];

                var jamMasuk = (DateTime)kendaraanKeluar["JamKeluar"];
                var JamKeluar = DateTime.Now;
                var type = (int)kendaraanKeluar["Type_Kendaraan"];
                var totalJam = Math.Ceiling((jamMasuk - JamKeluar).TotalHours);
                double totalBayar = 0;
                if (type == 1)
                {
                    totalBayar = 3000 + totalJam;
                }
            }
        }
    }
}