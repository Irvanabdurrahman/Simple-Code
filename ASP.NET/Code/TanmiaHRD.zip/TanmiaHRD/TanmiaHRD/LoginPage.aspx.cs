﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Security;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TanmiaHRD
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            var username = TextBox1.Text;
            var password = TextBox2.Text;

            if (username == "admin" && password=="12345")
            {
                FormsAuthenticationTicket tiket = new FormsAuthenticationTicket(
                    1,
                    username,
                    DateTime.Now,
                    DateTime.Now.AddMinutes(30),
                    false,
                    "Admin"
                    );

                HttpCookie cookie = new HttpCookie(
                    FormsAuthentication.FormsCookieName,
                    FormsAuthentication.Encrypt(tiket));
                Response.Cookies.Add(cookie);

                Response.Redirect("ListDepartment.aspx");
            }else
            {
                Label1.Text = "User name dan password salah";
            }
        }
    }
}