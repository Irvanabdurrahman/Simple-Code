﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TanmiaHRD
{
    public partial class AddPegawai : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void FormView1_PageIndexChanging(object sender, FormViewPageEventArgs e)
        {

        }

        protected void InsertButton_Click(object sender, EventArgs e)
        {

        }

        protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e)
        {
            Server.Transfer("ListPegawai.aspx");
        }

        protected void FormView1_ItemInserting(object sender, FormViewInsertEventArgs e)
        {
            var TglLahir = ((Calendar)FormView1.FindControl("Calendar1")).SelectedDate;
            var NamaPegawai = ((TextBox)FormView1.FindControl("NamaPegawaiTextBox")).Text;
            var label = ((Literal)FormView1.FindControl("Literal1"));
            List<String> ErrorText = new List<string>();
            var IsValid = true;

            if (TglLahir.Year >= 2017 )
            {
                ErrorText.Add("User Masih Anak-anak");
                IsValid = false;
            }

            if (string.IsNullOrEmpty(NamaPegawai))
            {
                ErrorText.Add("Nama pegawai tidak boleh kosong");
                IsValid = false;
            }

            if (!IsValid)
            {
                e.Cancel = true;
                var txt = "<div style='color:red;'><ul>";
                foreach(var item in ErrorText)
                {
                    txt += "<li>" + item + "</li>";
                }
                txt += "</ul></div>";
                label.Text = txt;
            }
        }

        protected void NamaPegawaiTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}